from django.contrib import admin
from .models import Project, ProjectBuy





admin.site.register(Project)
admin.site.register(ProjectBuy)
